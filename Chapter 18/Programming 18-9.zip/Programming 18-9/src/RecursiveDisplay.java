/*
Chauncy Wilson, Object-Oriented Programming 2

12/1/22, Reverse printing with recursive method
 */

import java.util.Scanner;

public class RecursiveDisplay {
    private static int j = 1;
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Type your text here: ");
        String value = input.nextLine();

        reverseDisplay(value);
    }

    private static void reverseDisplay(String value) {
        int j = getJ();
        int i = value.length() - j;
        char a = value.charAt(i);
        System.out.print(a);
        if (value.length() - j != 0) {
            reverseDisplay(value);
        }
    }

    private static int getJ() {
        return j++;
    }
}
