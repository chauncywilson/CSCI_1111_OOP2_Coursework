/*
Chauncy Wilson, Object-Oriented Programming 2

12/1/22, Recursion to find the greatest common denominator
 */

import java.util.Scanner;

public class GCDCalculator {
    double numerator = 0;
    double denominator = 1;
    int i = 1;
    int gcd = 0;

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        GCDCalculator gcdCalculator = new GCDCalculator();

        System.out.print("To calculate the gdc.");
        System.out.print("\nEnter the numerator: ");
        gcdCalculator.setNumerator(input.nextDouble());
        double tempNumerator = gcdCalculator.getNumerator();

        System.out.print("\nEnter the denominator: ");
        gcdCalculator.setDenominator(input.nextDouble());

        gcdCalculator.gcd(gcdCalculator.numerator, gcdCalculator.denominator);
        if (gcdCalculator.getGCD() == 0) {
            System.out.printf("%.0f/%.0f has no common denominator", tempNumerator,
                    gcdCalculator.denominator);
        }
        else {

            System.out.printf("%d is the greatest common denominator of %.0f/%.0f",
                    gcdCalculator.gcd, gcdCalculator.numerator, gcdCalculator.denominator);
        }
    }



    GCDCalculator(){}

    private void gcd(double numerator, double denominator) {
        int i = getI();
        if (numerator % i == 0 && denominator % i ==0) {
            setGCD(i);
        }
        else if (numerator >= i){
            gcd(numerator, denominator);
        }
    }

    private void setGCD(int i) {
        this.gcd = i;
    }

    private int getGCD() {
        return gcd;
    }

    private int getI() {
        return ++i;
    }

    public double getNumerator() {
        return numerator;
    }

    public void setNumerator(double numerator) {
        this.numerator = numerator;
    }

    public void setDenominator(double denominator) {
        this.denominator = denominator;
    }
}
