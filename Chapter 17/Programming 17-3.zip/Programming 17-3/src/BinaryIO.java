/*
Chauncy Wilson, Object-Oriented Programming 2
11/28/22, Making a binary file with written input
 */

import java.io.*;

public class BinaryIO {
    public static void main(String[] args) {
        BinaryIO binaryIO = new BinaryIO();
        binaryIO.write();
    }

    public void write(){
        File file = new File("Exercise17_03.dat");
        try (
                DataOutputStream output = new DataOutputStream(
                        new FileOutputStream(file))
        ) {
            for (int i = 0; i < 100; ++i) {
                output.writeInt((int) (Math.random() * 10));
            }
            read(file);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void read(File file) throws FileNotFoundException {
        try (DataInputStream input = new DataInputStream(new FileInputStream(file))){
            for (int i = 0; i < file.length() - 1; i++) {
                int a = input.readInt();
                int b = input.readInt();
                int c = a + b;
                System.out.println(a + " + " + b + " = " + c);
            }
        }
        catch (EOFException ex) {
            System.out.println("End of data");
        }
        catch (IOException e) {
            e.printStackTrace();
        }

    }
}
