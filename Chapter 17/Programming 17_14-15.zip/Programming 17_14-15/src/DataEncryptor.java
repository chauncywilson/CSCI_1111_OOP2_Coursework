/*
Chauncy Wilson, Object-Oriented Programming 2

11/29/22, Data encryption and a search function
 */

import java.io.*;
import java.util.Scanner;

public class DataEncryptor {
    public static void main(String[] args) {
        //Data Encrypt by adding a 5 to every byte in the file
        //8 bits is 1 byte
        Scanner input = new Scanner(System.in);

        System.out.println("Please enter the file you would like to encrypt: ");
        File file1 = new File(input.nextLine());

        System.out.println("Please enter the a name for the file: ");
        File file2 = new File(input.nextLine());

        try ( BufferedInputStream inputStream = new BufferedInputStream(new FileInputStream(file1));
        BufferedOutputStream outputStream = new BufferedOutputStream(new FileOutputStream(file2))
        ) {
            int r, numberOfBytesCopied = 0;
            while ((r = inputStream.read()) != -1) {
                outputStream.write(r);
                numberOfBytesCopied++;
            }
            inputStream.close();
            outputStream.close();
            System.out.println(numberOfBytesCopied + " bytes copied");

        } catch (IOException e) {
            e.printStackTrace();
        }

        try (RandomAccessFile inout = new RandomAccessFile(file2, "rw")) {
            inout.seek(0);
            int i = 0;
            while (i > inout.length() - 1){
                inout.read();
                inout.write(5);
                i++;
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Please enter the file you would like to decrypt: ");
        File file3 = new File(input.nextLine());

        System.out.println("Please enter a new location for the file: ");
        File file4 = new File(input.nextLine());

        try ( BufferedInputStream inputStream = new BufferedInputStream(new FileInputStream(file3));
              BufferedOutputStream outputStream = new BufferedOutputStream(new FileOutputStream(file4))
        ) {
            int r;
            while ((r = inputStream.read()) != -1) {
                outputStream.write(r);
            }
            inputStream.close();
            outputStream.close();
            System.out.println("");

        } catch (IOException e) {
            e.printStackTrace();
        }

        try (RandomAccessFile inout = new RandomAccessFile(file4, "rw")) {
            inout.seek(0);
            for (int i = 0; i < inout.length(); i++) {
                System.out.println(inout.read());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}