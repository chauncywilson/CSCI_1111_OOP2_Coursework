import java.io.*;

public class DataTest {
    public static void main(String[] args) throws IOException {

        File file = new File("Exercise17_14(1).dat");
        FileInputStream inputStream = new FileInputStream(file);

        int r;
        do{
            r = inputStream.read();
            System.out.println(r);
        }
        while (r != -1);
    }
}
