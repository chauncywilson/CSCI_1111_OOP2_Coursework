/*
Chauncy Wilson, Object-Oriented programming 2

10/22/22, I/O .txt file
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class IOTxtFile {
    public static void main(String[] args) {
        try {
            File file = new File("Exercise17_01.txt");
            PrintWriter output = new PrintWriter(file);

            for (int i = 0, j = 0; i < 100; i++) {
                output.append(String.valueOf((int) (Math.random() * 100))).append(" ");
                j++;
                if (j == 10) {
                    output.append("\n");
                    j = 0;
                }
            }
            output.close();
        }
        catch (FileNotFoundException exception) {
            System.out.println("File does not exist");
        }

    }
}
