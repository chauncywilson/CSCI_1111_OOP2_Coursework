/*
Chauncy Wilson, Object-Oriented Programming 2

11/10/22, Moving a ball with listeners
*/

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.scene.control.*;

//May have an infinite loop, best to check not to sure what is going on right now.
public class BallPane extends Application {
   public static void main(String[] args) {
       launch();
   }

   private final Circle circle = new Circle(50);
   int width = 600;
   int height = 400;
   int x = 300;
   int y = 200;

   @Override
   public void start(Stage primaryStage) {
       BorderPane pane = new BorderPane();

       Button btUp = new Button("Up");
       Button btDown = new Button("Down");
       Button btLeft = new Button("Left");
       Button btRight = new Button("Right");


       btUp.setOnAction(new UpButtonClass());
       btDown.setOnAction(new DownButtonClass());
       btLeft.setOnAction(new LeftButtonClass());
       btRight.setOnAction(new RightButtonClass());

       pane.setBottom(getHBox(btUp, btDown, btLeft, btRight));
       pane.getChildren().add(move());

       Scene scene = new Scene(pane, width, height);
       primaryStage.setTitle("Ball Mover");

       primaryStage.setScene(scene);

       primaryStage.show();
   }

   public HBox getHBox(Button btUp, Button btDown, Button btLeft, Button btRight) {
       HBox hBox = new HBox(15);

       hBox.getChildren().addAll(btUp, btDown, btLeft, btRight);

       return hBox;
   }

   Circle move() {
       circle.setCenterX(x);
       circle.setCenterY(y);
       circle.setStroke(Color.BLACK);
       circle.setFill(Color.WHITE);
       return circle;
   }

   class UpButtonClass implements EventHandler<ActionEvent> {
       @Override
       public void handle(ActionEvent upButton) {
           if (y > 50) {
           y -= 10;
           move();
           }
       }
   }

   class DownButtonClass implements EventHandler<ActionEvent> {
       @Override
       public void handle(ActionEvent downButton) {
           if (y < 350) {
               y += 10;
               move();
           }
       }
   }

   class LeftButtonClass implements EventHandler<ActionEvent> {
       @Override
       public void handle(ActionEvent leftButton) {
           if (x > 50) {
               x -= 10;
               move();
           }
       }
   }

   class RightButtonClass implements EventHandler<ActionEvent> {
       @Override
       public void handle(ActionEvent rightButton) {
           if (x < 550) {
               x += 10;
               move();
           }
       }
   }
}

