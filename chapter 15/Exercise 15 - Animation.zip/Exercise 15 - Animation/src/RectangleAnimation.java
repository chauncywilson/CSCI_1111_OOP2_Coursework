/*
Chauncy Wilson, Object-Oriented Programming 2

11/14/22, This program makes a rectangle the moves around a pentagon and the rectangle's opacity can be changed
 */

import javafx.animation.PathTransition;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.TilePane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;


//Animation Time! Let's Go!
public class RectangleAnimation extends Application {
    public static void main(String[] args) {
        launch();
    }

    private final Rectangle RECTANGLE = new Rectangle(0, 0, 25, 50);
    private final Polygon PENTAGON = new Polygon();

    final double WIDTH = 400;
    final double HEIGHT = 400;

    double centerX = WIDTH / 2;
    double centerY = HEIGHT / 2;
    double radius = Math.min(WIDTH, HEIGHT) * 0.3;

    int i = 0;
    double opacity = 0.5;

    @Override
    public void start(Stage primaryStage) {
        Pane pane = new Pane();

        RECTANGLE.setStroke(Color.BLACK);
        RECTANGLE.setFill(Color.BLACK);
        RECTANGLE.setOpacity(opacity);

        getPentagon();

        Button button1 = new Button("+");
        button1.setOnAction(new Button1HandlerClass());

        Button button2 = new Button("-");
        button2.setOnAction(new Button2HandlerClass());

        HBox hBox = setHBox(button1, button2);

        PathTransition pathTransition = new PathTransition();
        pathTransition.setDuration(Duration.millis(5000));
        pathTransition.setPath(PENTAGON);
        pathTransition.setNode(RECTANGLE);
        pathTransition.setOrientation(
            PathTransition.OrientationType.ORTHOGONAL_TO_TANGENT);
        pathTransition.setCycleCount(Timeline.INDEFINITE);
        pathTransition.play();

        PENTAGON.setOnMousePressed(event -> pathTransition.pause());
        PENTAGON.setOnMouseReleased(event -> pathTransition.play());
        pane.getChildren().clear();
        pane.getChildren().addAll(RECTANGLE, PENTAGON, hBox);

        Scene scene = new Scene(pane, WIDTH, HEIGHT);
        primaryStage.setTitle("Rectangle Orbit");
        primaryStage.setScene(scene);
        primaryStage.show();
    }


    public void getPentagon() {
        ObservableList<Double> list = PENTAGON.getPoints();
        for (int i = 0; i < 5; i++) {
            list.add(centerX + radius * Math.cos(2 * i * Math.PI / 5));
            list.add(centerY + radius * Math.sin(2 * i * Math.PI / 5));
        }
        PENTAGON.setRotate(55);
        PENTAGON.setFill(Color.BLUE);
        PENTAGON.setOpacity(.75);
    }


    public HBox setHBox(Button button1, Button button2) {
        HBox hBox = new HBox(button1, button2);
        hBox.setSpacing(5);
        return hBox;
    }

    class Button1HandlerClass implements EventHandler<ActionEvent> {
        @Override
        public void handle(ActionEvent e) {
            if (opacity != 1) {
                opacity += .1;
                RECTANGLE.setOpacity(opacity);
            }
        }
    }

    class Button2HandlerClass implements EventHandler<ActionEvent> {
        @Override
        public void handle(ActionEvent e) {
            if (opacity != 0) {
                opacity -= .1;
                RECTANGLE.setOpacity(opacity);
            }
        }
    }
}