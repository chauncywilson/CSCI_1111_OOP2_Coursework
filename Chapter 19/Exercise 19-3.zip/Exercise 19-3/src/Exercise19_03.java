/*
Author: Chauncy Wilson
Date: 12/5/22
Description: Generic method to remove duplicates
 */
import java.util.ArrayList;

public class Exercise19_03 {
    public static void main(String[] args) {
      ArrayList<Integer> list = new ArrayList<>();
      list.add(14);
      list.add(24);
      list.add(14);
      list.add(42);
      list.add(25);

      ArrayList<Integer> newList = removeDuplicates(list);
    
      System.out.print(newList);
    }

    public static <E> ArrayList<E> removeDuplicates(ArrayList<E> list) {
        E currentMin;
        E currentMinIndex;

        for (int i = 0; i < list.size() - 1; i++) {
            currentMin = list.get(i);

            for (int j = i + 1; j < list.size() - 1; j++) {
                currentMinIndex = list.get(j);
                if (currentMinIndex.equals(currentMin)) {
                    list.remove(j);
                }
            }
        }
        return list;
    }
}