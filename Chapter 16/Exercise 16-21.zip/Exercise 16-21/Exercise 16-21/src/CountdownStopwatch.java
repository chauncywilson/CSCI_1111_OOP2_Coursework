/*
Chauncy Wilson, Object-Oriented Programming 2

11/21/22, Stopwatch to media player
 */

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;
import javafx.util.Duration;

import static java.lang.Integer.parseInt;

public class CountdownStopwatch extends Application {
    public static void main(String[] args) {
        launch();
    }

    TextField textField = new TextField("0s");
    int timer = -1;
    int currentFrame;

    @Override
    public void start(Stage primaryStage) {
        EventHandler<ActionEvent> onFinished = e -> {
            timer--;
            textField.setText(timer + "s");

            if (textField.getText().equals("0s")){
                textField.setOpacity(0);
                startMedia();
            }
        };

        Timeline animation = new Timeline(new KeyFrame(Duration.millis(1000), onFinished));

        textField.setAlignment(Pos.CENTER);
        textField.setOnAction(event -> {
            setTimer();
            currentFrame = setCurrentFrame();
            animation.setCycleCount(timer);
            animation.play();
        });

        BorderPane borderPane = new BorderPane(textField);

        Scene scene = new Scene(borderPane, 200, 200);

        primaryStage.setTitle("Stopwatch");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void startMedia() {
        Media media = new Media("https://liveexample.pearsoncmg.com/common/audio/anthem/anthem0.mp3");
        MediaPlayer mediaPlayer = new MediaPlayer(media);
        mediaPlayer.setCycleCount(Timeline.INDEFINITE);
        mediaPlayer.play();
    }

    private void setTimer() {
        String number = textField.getText();
        timer = parseInt(number);
    }

    private int setCurrentFrame() {
        String number = textField.getText();
        return parseInt(number);
    }
}