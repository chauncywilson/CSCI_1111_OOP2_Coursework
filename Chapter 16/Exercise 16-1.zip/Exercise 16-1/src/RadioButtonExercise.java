/*
Chauncy Wilson, Object-Oriented Programming 2

11/17/22, Radio buttons, and color changing text
 */


import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class RadioButtonExercise extends Application {
    //Main method only needed for the code to compile
    public static void main(String[] args) {
        launch();
    }

    final int WIDTH = 500;
    final int HEIGHT = 200;

    @Override
    public void start(Stage primaryStage) throws Exception {
        //Left and Right Button get methods
        Button btLeft = getLeftButton();
        Button btRight = getRightButton();

        //Radio Buttons get methods
        RadioButton rbRed = new RadioButton("Red");
        RadioButton rbYellow = new RadioButton("Yellow");
        RadioButton rbBlack = new RadioButton("Black");
        RadioButton rbOrange = new RadioButton("Orange");
        RadioButton rbGreen = new RadioButton("Green");

        //Text as a rectangle
        Text text = getText();

        //HBox getters
        HBox bottomHBox = getBottomHBox(btLeft, btRight);
        HBox topHBox = getTopHBox(rbRed, rbYellow, rbBlack, rbOrange, rbGreen);

        //Border Pane
        BorderPane borderPane = new BorderPane();
        borderPane.setBottom(bottomHBox);
        borderPane.setTop(topHBox);
        borderPane.getChildren().add(text);
        borderPane.getChildren().addAll();

        //Radio button Toggle group
        ToggleGroup radioButtons = new ToggleGroup();
        rbRed.setToggleGroup(radioButtons);
        rbYellow.setToggleGroup(radioButtons);
        rbBlack.setToggleGroup(radioButtons);
        rbOrange.setToggleGroup(radioButtons);
        rbGreen.setToggleGroup(radioButtons);

        //Button Action Handlers
        btLeft.setOnAction(e -> text.setX(text.getX() - 10));
        btRight.setOnAction(e -> text.setX(text.getX() + 10));

        rbRed.setOnAction(event -> text.setFill(Color.RED));
        rbYellow.setOnAction(event -> text.setFill(Color.YELLOW));
        rbBlack.setOnAction(event -> text.setFill(Color.BLACK));
        rbOrange.setOnAction(event -> text.setFill(Color.ORANGE));
        rbGreen.setOnAction(event -> text.setFill(Color.GREEN));

        //Scene
        Scene scene = new Scene(borderPane, WIDTH, HEIGHT);
        primaryStage.setTitle("Exercise 16_01");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private Text getText() {
        Text text = new Text("Programming is fun");
        text.setFont(Font.font("Sans", 20));
        text.setX(150);
        text.setY(100);
        return text;
    }

    private HBox getTopHBox(RadioButton rbRed, RadioButton rbYellow, RadioButton rbBlack,
                            RadioButton rbOrange, RadioButton rbGreen) {
        HBox topHBox = new HBox(10, rbRed, rbYellow, rbBlack, rbOrange, rbGreen);
        topHBox.setAlignment(Pos.CENTER);
        return topHBox;
    }

    private HBox getBottomHBox(Button btLeft, Button btRight) {
        HBox bottomHBox = new HBox(5, btLeft, btRight);
        bottomHBox.setAlignment(Pos.CENTER);
        return bottomHBox;
    }

    private Button getRightButton() {
        return new Button("->");
    }

    private Button getLeftButton() {
        return new Button("<-");
    }
}
