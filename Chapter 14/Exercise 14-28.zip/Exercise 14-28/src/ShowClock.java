/*
Chauncy Wilson, Object-Oriented Programming 2

Test a random value for the clock
*/

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class ShowClock extends Application {
    @Override
    public void start(Stage primaryStage) {
        NewClock clock = new NewClock();
        clock.setHour((int) (Math.random() * 11));
        clock.setMinute((int) (Math.random() * 30));
        clock.setSecond((int) (Math.random() * 60));

        clock.setHourHandVisible(true);
        clock.setMinuteHandVisible(true);
        clock.setSecondHandVisible(false);

        String time = (clock.getHour() + ":" + clock.getMinute() + ":" + clock.getSecond());
        clock.paintClock();
        Label clockTime = new Label(time);

        Pane pane = new Pane();
        pane.getChildren().clear();
        pane.getChildren().addAll(clock, clockTime);

        Scene scene = new Scene(pane, 250, 250);
        primaryStage.setTitle("Clock");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}

